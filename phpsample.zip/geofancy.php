<?php

$params = "";
foreach ($_REQUEST as $key => $value) {
	$params .= "Key: $key * Value: $value\n";
}

$params .= "\n";

$fh = fopen('geofancy.txt', 'a');
fwrite($fh, $params);
fclose($fh);

?>